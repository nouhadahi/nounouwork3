'use strict';

App.controller('UserController', function($scope, UserService, $mdDialog, $uibModal,
		$mdMedia) {
	var self = this;
	self.user = {
		id : null,
		username : '',
		address : '',
		email : ''
	};
	self.users = [];

	self.fetchAllUsers = function() {
		UserService.fetchAllUsers().then(function(d) {
			self.users = d;
		}, function(errResponse) {
			console.error('Error while fetching Currencies');
		});
	};

	


});
function DialogController($scope, $mdDialog) {
	$scope.hide = function() {
		$mdDialog.hide();
	};

	$scope.cancel = function() {
		$mdDialog.cancel();
	};

	$scope.answer = function(answer) {
		$mdDialog.hide(answer);
	};
}
