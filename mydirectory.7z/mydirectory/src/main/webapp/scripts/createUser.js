App.controller('CreateUserCtrl', function ($rootScope,UserService,$uibModal,$scope,$log,$uibModalStack) {

 
	       var self = this;
          self.user={
			firstName : null,
			lastName : '',
			address : '',
			email : ''
		};

    var modalInstance;
    
    $scope.saveUser = function(){
      UserService.createUser( self.user);
        $log.log("saving user");
		 $uibModalStack.dismissAll();
    };
    $scope.openCreateUser = function () {

         modalInstance = $uibModal.open({
          animation: true,
          templateUrl: 'myModalContent.html',
          controller: 'CreateUserCtrl',        
          resolve: {
            items: function () {
              return $scope.items;
            }
          }
        });

        modalInstance.result.then(function (selectedItem) {
          $scope.selected = selectedItem;
        }, function () {
          $log.info('Modal dismissed at: ' + new Date());
        });
      };
  });
